import { createTheme } from '@mui/material/styles';

import { muiTheme } from './constants';

export const mainTheme = createTheme({
  ...muiTheme,
});
