import palette from '../palette';

export default {
  styleOverrides: {
    root: {
      fontSize: '14px',
      fontWeight: '400',
      alignItems: 'center',
      marginBottom: '8px',
    },
  },
};
