export default {
  styleOverrides: {
    root: {
      width: '100%',
      boxSizing: 'border-box' as 'border-box',
      padding: '15px 0',
    },
  },
};
