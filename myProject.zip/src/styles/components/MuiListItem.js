export default {
  // styleOverrides: {
  //   dense: {
  //     paddingTop: 1,
  //     paddingBottom: 1,
  //   },
  //   gutters: {
  //     paddingLeft: 20,
  //     paddingRight: 20,
  //   },
  // },
};
