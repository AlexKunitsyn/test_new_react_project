import palette from '@styles/palette';

export default {
  styleOverrides: {
    indicator: {
      height: 3,
      // backgroundColor: palette.secondaryOrange,
      borderTopLeftRadius: 3,
      borderTopRightRadius: 3,
    },
  },
};
