import palette from '../palette';

export default {
  styleOverrides: {
    // root: {
    //   zIndex: 2000,
    // },
  },
};
