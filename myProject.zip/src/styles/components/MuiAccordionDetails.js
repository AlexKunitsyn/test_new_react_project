export default {
  styleOverrides: {
    root: {
      display: 'block',
      paddingLeft: '24px',
      paddingRight: '24px',
      paddingBottom: '24px',
      paddingTop: 0,
    },
  },
};
