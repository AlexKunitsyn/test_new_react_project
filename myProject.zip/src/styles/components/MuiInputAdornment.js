export default {
  styleOverrides: {
    filled: {
      '&.MuiInputAdornment-positionStart:not(.MuiInputAdornment-hiddenLabel)': {
        marginTop: 0,
      },
    },
  },
};
