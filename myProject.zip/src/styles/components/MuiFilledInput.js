import palette from '../palette';

export default {
  // styleOverrides: {
  //   root: {
  //     backgroundColor: palette.secondary.light,
  //     borderRadius: 28,
  //
  //     '&:hover': {
  //       backgroundColor: palette.secondary.light,
  //     },
  //
  //     '&$focused': {
  //       backgroundColor: palette.secondary.light,
  //     },
  //     '&$blur': {
  //       backgroundColor: palette.secondary.light,
  //     },
  //   },
  // },
};
