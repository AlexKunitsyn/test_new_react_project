import palette from '../palette';

export default {
  styleOverrides: {
    root: {
      fontSize: '12px',
      marginLeft: 0,
      marginTop: '4px',
    },
  },
};
