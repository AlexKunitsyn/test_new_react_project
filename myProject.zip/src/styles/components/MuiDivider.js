import palette from '../palette';

export default {
  styleOverrides: {
    root: {
      backgroundColor: palette.secondary.light,
    },
  },
};
