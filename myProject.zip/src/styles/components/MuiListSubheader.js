export default {
  styleOverrides: {
    root: {
      lineHeight: '40px',

      '& .MuiTypography-root': {
        fontWeight: 500,
      },
    },
  },
};
