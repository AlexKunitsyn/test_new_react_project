import palette from '../palette';

export default {
  styleOverrides: {
    root: {
      // color: 'transparent',
    },
  },
};
