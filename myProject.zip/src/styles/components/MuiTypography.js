export default {
  defaultProps: {
    variantMapping: {
      body3: 'p',
      subtitle3: 'p',
      subtitle2: 'p',
      subtitle4: 'p',
      subtitle5: 'p',
      caption: 'p',
    },
  },
};
