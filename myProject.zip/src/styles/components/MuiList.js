export default {
  styleOverrides: {
    padding: {
      paddingTop: 15,
      paddingBottom: 15,
    },
  },
};
