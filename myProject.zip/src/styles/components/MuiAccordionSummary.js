export default {
  styleOverrides: {
    root: {
      paddingLeft: '24px',
      paddingRight: '24px',
      paddingTop: '14px',
      paddingBottom: '14px',
      // '&.Mui-expanded': {
      //   minHeight: '30px',
      // },
    },

    content: {
      margin: '6px 0',

      // '&.Mui-expanded': {
      //   margin: '8px 0',
      // },
    },
  },
};
