import React from 'react';
import Box from "@mui/material/Box";

const About = () => {
    return (
        <Box>

            <h1>About Page</h1>
            <p>Welcome to the about page!</p>
        </Box>
    );
};

export default About;